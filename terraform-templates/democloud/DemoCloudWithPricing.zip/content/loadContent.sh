#!/bin/bash


## getting the arguments
filepath=$1
host=$2
service_url=$host/genericcontentserver/v1/admin/import
apikey_username=$3
apikey=$4

## creating a log
log_file=output.log
echo "$(date)  the parameters got as:: filepath= $filepath; service url = $service_url" | tee -a $log_file

## creating tar.gz file 
tar -zcvf ./final_catalog.tar.gz *

### uploading catalog with generic content server
command=$(curl -v -k  -H "Content-Type: multipart/form-data" -H "username:$apikey_username" -H "apikey:$apikey" -X POST -F file=@final_catalog.tar.gz "$service_url")

echo "$(date)  the response got from server is:: $command" | tee -a $log_file
echo "#################" | tee -a $log_file